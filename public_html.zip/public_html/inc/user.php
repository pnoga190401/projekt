<?php
int_set('session.use_cookies', 1);
int_set('session.use_only_cookies', 1);
int_set('session.save_path', "sesje" );
int_set('session.gc_probability', 1);
int_set('session.cookie_httponly', 1);

class user(
    var $uVal = 'uval';
    var $remTime = 7200; // 2 godz.
    var $remCookieComain = ''; // 2 godz.
    var $remCookieName = 'sqlDB'; // 2 godz.
    var $keys = array('uid', 'login', 'haslo', 'email', 'datad'); // 2 godz.
    var $dane;
    
    function __construct() {
		$this->remCookieDomain = ($this->remCookieDomain == '' ? $_SERVER['HTTP_HOST'] : $this->remCookieDomain);
		if(!isset($_SESSION)) session_start();
		if(!empty($_SESSION[$this->uVal])) $this->is_user($_SESSION[$this->uVal]);
		if (isset($_COOKIE[$this->remCookieName]) && !$this->uid) {
			$u = unserialize(base64_decode($_COOKIE[$this->remCookieName]));
			$this->login($u['nick'],$u['haslo'],false,true);
		}
		if (!$this->uid && isset($_POST['loguj'])) {
			$n = clrtxt($_POST['nick']); //nazwa użytkownika
			$h = clrtxt($_POST['haslo']); //hasło użytkownika
			$this->login($n,$h,true,true);
		}
		if (isset($_GET['unlog'])) $this->logout();
}    

    function is_user($id, $login=NULL, $haslo=NULL){
        if (!empty($login)){
            $qstr='SELECT * FROM users WHERE login=\''.$login.'\' AND haslo =\''.sha1($haslo).'\' LIMIT 1';
        } else return false;
        
        $ret = array();
        db_query($qstr, $ret);
        if (!empty($ret[0])) {
            $this->dane=array_merge($this->dane, $ret[0]);
            $sid = sha1($this->uid.$this->login.session_id());
            $_SESSION[$this->uVal] = $sid;
            return true;
        }    
}
?>
