<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
?>
<footer class=" py-5">

    <div class="container">
        <div class="row text-light">

            <div class="col-md-4">
				
			<?php get_component('mono_footer1');?>
			</div>
         
			 <div class="col-md-4">
				
			<?php get_component('mono_footer2');?>
			</div>
			
			 <div class="col-md-4">
				
			<?php get_component('mono_footer3');?>
			</div>
        </div>
    </div>

</footer>
<div class="subfooter bg-dark text-center text-light py-2" >

    Created by multicolor <?php echo date('Y'); ?>   | <i class="fas fa-heart"></i> Get Simple CMS

</div>



    <script src="<?php get_theme_url();?>/script.js"></script>
  </body>
</html>
